import torch
import torch.nn as nn


class AttentionFusion(nn.Module):
    def __init__(self, hidden_dim=16, num_heads=4, dropout=0.1):
        super().__init__()
        self.attention = nn.MultiheadAttention(
            embed_dim=hidden_dim,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True
        )
        self.value_proj = nn.Linear(1, hidden_dim)
        self.output_net = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, 1),
            nn.Sigmoid()
        )

    def forward(self, adj1, adj2):
        N = adj1.size(0)
        device = adj1.device

        with torch.no_grad():
            mask = (adj1 > 0) | (adj2 > 0)
            indices = mask.nonzero(as_tuple=True)
            num_nonzero = indices[0].shape[0]

        values1 = adj1[indices].unsqueeze(-1)
        values2 = adj2[indices].unsqueeze(-1)

        v1 = self.value_proj(values1)
        v2 = self.value_proj(values2)

        modal_stack = torch.stack([v1, v2], dim=1)
        attn_output, _ = self.attention(modal_stack, modal_stack, modal_stack)
        aggregated = attn_output.mean(dim=1)
        fused_values = self.output_net(aggregated).squeeze(-1)

        fused_adj = torch.zeros(N, N, device=device)
        fused_adj[indices] = fused_values
        fused_adj = fused_adj * (1 - torch.eye(N, device=device))
        fused_adj = (fused_adj + fused_adj.t()) / 2

        row_sum = fused_adj.sum(dim=1, keepdim=True).clamp(min=1e-8)
        fused_adj = fused_adj / row_sum

        return fused_adj


class AttentiveGAE_VAE(nn.Module):
    def __init__(self, in_dim, hidden_dims, adj1, adj2):
        super().__init__()
        self.register_buffer('A1', adj1)
        self.register_buffer('A2', adj2)
        self.fusion = AttentionFusion()

        self.encoder = nn.Sequential(
            nn.Linear(in_dim, hidden_dims[0]),
            nn.BatchNorm1d(hidden_dims[0]),

            nn.ReLU(),
            nn.Linear(hidden_dims[0], hidden_dims[1] * 2),
            nn.BatchNorm1d(hidden_dims[1] * 2),  # 对合并后的均值+方差进行归一化
            nn.ReLU()

        )

        self.decoder = nn.Sequential(
            nn.Linear(hidden_dims[1], hidden_dims[0]),
            nn.ReLU(),
            nn.Linear(hidden_dims[0], in_dim),
            nn.Sigmoid()  # 输出∈[0,1]
        )
        # 新增：临时存储类别数（训练时动态传入，不影响模型初始化）
        self.num_classes = None
    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x):
        A_fused = self.fusion(self.A1, self.A2)
        h = torch.mm(A_fused, x)
        h = self.encoder(h)
        mu, logvar = torch.chunk(h, 2, dim=-1)
        z = self.reparameterize(mu, logvar)
        x_recon = self.decoder(z)
        return x_recon, mu, logvar, A_fused