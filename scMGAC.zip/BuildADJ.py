import numpy as np
from scipy.sparse import csr_matrix


def build_rna_adjacency(adata, k=15, return_sparse=True):
    X = adata.X if isinstance(adata.X, np.ndarray) else adata.X.toarray()
    n_cells = X.shape[0]

    pearson_corr = np.corrcoef(X)
    sim_matrix = np.maximum(pearson_corr, 0)
    knn_indices = np.argsort(-sim_matrix, axis=1)[:, 1:k + 1]

    row_indices = np.repeat(np.arange(n_cells), k)
    col_indices = knn_indices.flatten()
    weights = sim_matrix[row_indices, col_indices]

    adj_matrix = csr_matrix((weights, (row_indices, col_indices)), shape=(n_cells, n_cells))
    adj_matrix = adj_matrix.maximum(adj_matrix.transpose())
    adj_matrix.setdiag(0)

    if not return_sparse:
        adj_matrix = adj_matrix.toarray()

    min_val = adj_matrix.min() if return_sparse else adj_matrix.data.min()
    max_val = adj_matrix.max() if return_sparse else adj_matrix.data.max()
    print(f"RNA adjacency matrix shape: {adj_matrix.shape} (cells × cells), value range: [{min_val:.4f}, {max_val:.4f}]")
    return adj_matrix

