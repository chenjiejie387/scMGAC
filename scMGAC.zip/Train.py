from sklearn.preprocessing import MinMaxScaler
import scanpy as sc
import pandas as pd
import numpy as np
from scipy.sparse import csr_matrix
from sklearn.metrics.pairwise import cosine_similarity
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, confusion_matrix
from sklearn.preprocessing import LabelEncoder
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import os
import matplotlib.patches as mpatches
from scipy.optimize import linear_sum_assignment
from Processing import preprocess_gene_expression,process_activity_matrix
from BuildADJ import build_rna_adjacency
from model import AttentionFusion,AttentiveGAE_VAE
def train_attentive_model(model, X, true_labels, device, n_epochs=100, lr=0.01, beta=0.05, gamma=0.0001):
    model.num_classes = len(np.unique(true_labels))

    model.to(device)
    optimizer = optim.Adam(model.parameters(), lr=lr)
    true_labels_tensor = torch.tensor(true_labels, dtype=torch.long, device=device)

    # -------------------------- Added: Initialize loss tracking container --------------------------
    loss_history = {
        'epoch': [],  # Iteration number
        'recon_loss': [],  # Reconstruction loss
        'kl_loss': [],  # KL divergence loss
        'consensus_loss': [],  # Consistency loss
        'total_loss': []  # Total loss
    }
    for epoch in range(n_epochs):
        model.train()
        optimizer.zero_grad()

        x_recon, mu, logvar, A_fused = model(X)

        # Calculate losses
        recon_loss = F.mse_loss(x_recon, X)
        kl_loss = -0.5 * torch.mean(torch.sum(1 + logvar - mu.pow(2) - logvar.exp(), dim=1))
        consensus_mask = (model.A1 > 0.5) & (model.A2 > 0.5)
        consensus_loss = F.binary_cross_entropy(
            A_fused[consensus_mask],
            torch.ones_like(A_fused[consensus_mask])
        )

        # Total loss:
        total_loss = recon_loss + beta * kl_loss + gamma * consensus_loss
        total_loss.backward()
        optimizer.step()

        # -------------------------- Added: Record current epoch loss --------------------------
        loss_history['epoch'].append(epoch + 1)  # Epoch starts from 1 for better clarity
        loss_history['recon_loss'].append(recon_loss.item())
        loss_history['kl_loss'].append(kl_loss.item())
        loss_history['consensus_loss'].append(consensus_loss.item())
        loss_history['total_loss'].append(total_loss.item())

        # Evaluate clustering
        with torch.no_grad():
            latent = mu.cpu().numpy()
            kmeans = KMeans(n_clusters=len(np.unique(true_labels))).fit(latent)
            ari = adjusted_rand_score(true_labels, kmeans.labels_)

        # Print training info
        if (epoch + 1) % 10 == 0 or epoch == 0:
            print(f'Epoch {epoch + 1}/{n_epochs} | '
                  f'Recon Loss: {recon_loss.item():.4f} | '
                  f'KL Loss: {kl_loss.item():.4f} | '
                  f'Consensus Loss: {consensus_loss.item():.4f} | '
                  f'Total Loss: {total_loss.item():.4f} | '
                  f'ARI: {ari:.4f}')

    return loss_history


def plot_loss_convergence_separate(loss_history, save_path, figsize=(16, 12)):
    """
    Plot each loss term (reconstruction, KL divergence, consensus, total) in separate subplots

    Parameters:
        loss_history: dict, Loss records returned by the training function, including epoch, recon_loss, kl_loss, consensus_loss, total_loss
        save_path: str, Image save path (including file name)
        figsize: tuple, Overall image size (width, height)
    """
    # Set font for better English display
    plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial']
    plt.rcParams['axes.unicode_minus'] = False

    # Define loss configurations: (label, color, marker, subplot_title)
    loss_configs = [
        (
            'Reconstruction Loss',
            '#1f77b4',
            'o',
            'Reconstruction Loss vs Epochs'
        ),
        (
            'KL Divergence Loss',
            '#ff7f0e',
            's',
            'KL Divergence Loss vs Epochs'
        ),
        (
            'Consensus Loss',
            '#2ca02c',
            '^',
            'Consensus Loss vs Epochs'
        ),
        (
            'Total Loss',
            '#d62728',
            'D',
            'Total Loss vs Epochs'
        )
    ]

    # Create 2x2 subplots (4 plots total)
    fig, axes = plt.subplots(2, 2, figsize=figsize)
    # Flatten axes array for easy iteration (convert 2x2 to 1x4)
    axes_flat = axes.flatten()
    epochs = loss_history['epoch']  # Get epoch list once for reuse

    # Plot each loss in a separate subplot
    for idx, (loss_key, (label, color, marker, title)) in enumerate(zip(
            ['recon_loss', 'kl_loss', 'consensus_loss', 'total_loss'],
            loss_configs
    )):
        ax = axes_flat[idx]
        # Plot current loss curve
        ax.plot(
            epochs,
            loss_history[loss_key],
            label=label,
            color=color,
            linewidth=2.5,
            marker=marker,
            markersize=4,
            linestyle='-' if loss_key != 'total_loss' else '--'  # Keep dashed line for total loss
        )

        # Set subplot style
        ax.set_title(title, fontsize=14, fontweight='bold', pad=15)
        ax.set_xlabel('Epoch', fontsize=12, fontweight='bold')
        ax.set_ylabel('Loss Value', fontsize=12, fontweight='bold')
        ax.legend(loc='upper right', fontsize=11, frameon=True, shadow=True)
        ax.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
        ax.set_xlim(left=1, right=max(epochs))  # Align x-axis range across all plots

        # Optional: Adjust y-axis to focus on loss variation (remove outliers)
        loss_vals = loss_history[loss_key]
        y_min = min(loss_vals) * 0.95 if min(loss_vals) > 0 else min(loss_vals) * 1.05
        y_max = max(loss_vals) * 1.05
        ax.set_ylim(bottom=y_min, top=y_max)

    # Add overall title for the entire figure
    fig.suptitle('Model Training Loss Convergence (Separate Plots)', fontsize=18, fontweight='bold', y=0.98)
    # Adjust spacing between subplots (prevent label overlap)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])  # Reserve space for suptitle

    # Ensure save directory exists
    save_dir = os.path.dirname(save_path)
    if not os.path.exists(save_dir):
        os.makedirs(save_dir, exist_ok=True)

    # Save high-resolution image
    plt.savefig(save_path, dpi=300, bbox_inches='tight', facecolor='white')
    print(f"Separate loss plots saved to: {save_path}")

if __name__ == "__main__":
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    # Load RNA data
    data = pd.read_csv('E:/jsj/user03/scATAC_data/human_pbmc3k/rna_counts.csv', index_col=0)
    data_filled = data.fillna(0)
    adata = sc.AnnData(data_filled.T)

    # RNA preprocessing
    adata_hvg = preprocess_gene_expression(adata)
    rna_features = adata_hvg.X.toarray()
    rna_adj = build_rna_adjacency(adata_hvg, k=15)
    rna_genes = [f"RNA_{gene}" for gene in adata_hvg.var_names.tolist()]
    rna_feature_cols = rna_features.shape[1]  # Directly get the actual column count of RNA features
    print(f"Number of RNA feature columns: {rna_feature_cols}, Number of gene names: {len(rna_genes)}")  # Can be used to verify consistency

    # Load ATAC data
    activity_df = pd.read_csv('E:/jsj/user03/scATAC_data/human_pbmc3k/atac_activity_matrix.csv', index_col=0)
    activity_df.columns = activity_df.columns.astype(str)
    atac_adj, atac_features = process_activity_matrix(activity_df, top_n=2000, k_for_knn=15, return_sparse=True)
    print("Length of activity_df.index:", len(activity_df.index))

    # Check the length of atac_features.columns
    print("Length of atac_features.columns:", len(atac_features.columns))
    atac_genes = [f"ATAC_{gene}" for gene in atac_features.columns]

    print("Length of atac_genes:", len(atac_genes))

    # Convert to numpy array
    atac_features = atac_features.values
    # Feature concatenation
    combined_features = np.hstack((rna_features, atac_features))
    all_genes = rna_genes + atac_genes
    print(f"Shape of concatenated features: {combined_features.shape}")

    # Process labels
    true_labels = pd.read_csv("E:/jsj/user03/scATAC_data/human_pbmc3k/clusters.csv")
    true_celltypes = true_labels['CellType'].values  # True cell types (original names)
    true_cluster = true_labels['Cluster']
    le = LabelEncoder()
    true_labels_encoded = le.fit_transform(true_cluster)
    print(f"Number of classes: {len(le.classes_)}")

    # Convert to tensor
    rna_adj_dense = rna_adj.toarray() if isinstance(rna_adj, csr_matrix) else rna_adj
    atac_adj_dense = atac_adj.toarray() if isinstance(atac_adj, csr_matrix) else atac_adj
    A1_tensor = torch.tensor(rna_adj_dense, dtype=torch.float32).to(device)
    A2_tensor = torch.tensor(atac_adj_dense, dtype=torch.float32).to(device)
    X_combined_tensor = torch.tensor(combined_features, dtype=torch.float32).to(device)

    # Initialize model
    model = AttentiveGAE_VAE(
        in_dim=X_combined_tensor.shape[1],
        hidden_dims=[256, 128],
        adj1=A1_tensor,
        adj2=A2_tensor
    )
    model.to(device)  # Ensure the model is sent to the same device (GPU or CPU)
    print("Model weights successfully loaded.")
    # Train model
    loss_history = train_attentive_model(
        model,
        X_combined_tensor,
        true_labels_encoded,
        device=device,
        n_epochs=500,
        lr=0.001,
        beta=0.0001,
        gamma=0.0001
    )

    print(f"Training complete")
    # Save model weights after training
    torch.save(model.state_dict(), "E:/jsj/user03/scATAC_data/human_pbmc3k/trained_model_weights2.pth")
    print("Model weights saved to: E:/jsj/user03/scATAC_data/human_pbmc3k/trained_model_weights2.pth")
    # Define image save path (same directory as t-SNE plot for easy management)
    loss_plot_save_path = "E:/jsj/user03/scATAC_data/human_pbmc3k/loss_convergence_curve.png"
    # Generate and save loss curve
    #plot_loss_convergence_separate(loss_history, save_path=loss_plot_save_path)

    # Post-processing after training: Get model output
    model.eval()
    with torch.no_grad():
        x_recon, mu, _, _ = model(X_combined_tensor)
        latent_embedding = mu.cpu().numpy()
        recon_matrix = x_recon.cpu().numpy()

    kmeans = KMeans(n_clusters=len(le.classes_), random_state=42).fit(latent_embedding)
    cluster_labels = kmeans.labels_
    # 2. KMeans clustering and save labels
    cluster_df = pd.DataFrame({'Cluster': cluster_labels})
    # Save as CSV
    cluster_df.to_csv("E:/jsj/user03/scATAC_data/human_pbmc3k/cluster_labels.csv", index=False)
    print(f"KMeans clustering labels saved to CSV file, shape: {cluster_labels.shape}")

    # 3. Split reconstructed matrix and restore original gene names
    # Split into RNA and ATAC parts
    rna_recon = recon_matrix[:, :rna_feature_cols]
    atac_recon = recon_matrix[:, rna_feature_cols:]

    # Restore original gene names (remove prefixes)
    original_rna_genes = [gene.replace("RNA_", "") for gene in rna_genes]
    original_atac_genes = [gene.replace("ATAC_", "") for gene in atac_genes]
    print("Length of original_rna_genes:", len(original_rna_genes))
    print("Length of original_atac_genes:", len(original_atac_genes))

    # Save as DataFrame
    rna_recon_df = pd.DataFrame(rna_recon,
                                index=adata_hvg.obs_names,
                                columns=original_rna_genes)
    atac_recon_df = pd.DataFrame(atac_recon,
                                 index=adata_hvg.obs_names,  # Assuming cell names are the same as RNA data
                                 columns=original_atac_genes)

    rna_recon_df.to_csv("E:/jsj/user03/scATAC_data/human_pbmc3k/output/rna_reconstructed.csv")
    atac_recon_df.to_csv("E:/jsj/user03/scATAC_data/human_pbmc3k/output/atac_reconstructed.csv")
    print(f"RNA reconstructed data saved to output/rna_reconstructed.csv, shape: {rna_recon.shape}")
    print(f"ATAC reconstructed data saved to output/atac_reconstructed.csv, shape: {atac_recon.shape}")

    print("All results successfully saved")

    # t-SNE dimensionality reduction visualization (New section)
    # --------------------------
    print("Starting cluster label and true cell type mapping...")

    # 1. Prepare matching data (true types and predicted cluster labels)
    # Ensure data order consistency (cluster labels and true labels match by cell)
    match_data = pd.DataFrame({
        'true_celltype': true_celltypes,  # True cell types (original names)
        'pred_cluster': cluster_labels  # Predicted cluster labels from the model
    })

    # 2. Compute confusion matrix (true types × predicted clusters)
    unique_celltypes = match_data['true_celltype'].unique()
    unique_clusters = match_data['pred_cluster'].unique()
    cm = confusion_matrix(
        match_data['true_celltype'],
        match_data['pred_cluster'],
        labels=unique_celltypes
    )

    # 3. Use Hungarian algorithm to find the optimal mapping (maximize matching count)
    row_indices, col_indices = linear_sum_assignment(cm, maximize=True)

    # 4. Build cluster → cell type mapping dictionary
    cluster_to_celltype = {}
    for row, col in zip(row_indices, col_indices):
        cluster = unique_clusters[col]
        celltype = unique_celltypes[row]
        cluster_to_celltype[cluster] = celltype

    # 5. Handle unmatched clusters (if any)
    for cluster in unique_clusters:
        if cluster not in cluster_to_celltype:
            # Assign unmatched clusters to the most common true type in that cluster
            cluster_mask = match_data['pred_cluster'] == cluster
            top_celltype = match_data[cluster_mask]['true_celltype'].mode().values[0]
            cluster_to_celltype[cluster] = top_celltype

    # 6. Convert each cell's cluster label to its true cell type
    mapped_celltypes = [cluster_to_celltype[cluster] for cluster in cluster_labels]
    print("Mapping complete, cluster-to-cell type mapping:")
    for cluster, celltype in cluster_to_celltype.items():
        print(f"Cluster {cluster} → {celltype}")

    # --------------------------
    # t-SNE Visualization (using true cell types as legend)
    # --------------------------
    print("Starting t-SNE dimensionality reduction visualization...")

    # t-SNE dimensionality reduction
    tsne = TSNE(n_components=2, random_state=12, perplexity=30)
    tsne_embeddings = tsne.fit_transform(latent_embedding)

    # Custom color palette
    custom_palette = ['#ecd452', '#e76254', '#44757a', '#c6a468', '#6D4E7E',
                      '#2e5496', '#299d8f', '#4994c4', '#8f6d5f', '#FAC050',
                      '#77B473', '#CBC2D7', '#D28450', '#DCC2AB', '#90C3B6',
                      '#FDC192', '#3854A6', '#727174', '#F3756D', '#FAF49B',
                      '#9172DB', '#5A9', '#B5D8FE', '#FF9F9B', '#DDBEA9']

    # Prepare color mapping by true cell type
    labels_to_plot = mapped_celltypes  # Use the mapped true cell types
    unique_labels = np.unique(labels_to_plot)
    num_labels = len(unique_labels)

    # Automatically expand the color list if needed
    if len(custom_palette) < num_labels:
        from matplotlib import cm

        additional_colors = [cm.tab20(i) for i in range(num_labels - len(custom_palette))]
        custom_palette.extend(additional_colors)
        print(f"Color list was insufficient, automatically expanded to {num_labels} colors")

    # Map labels to colors
    color_map = dict(zip(unique_labels, custom_palette[:num_labels]))
    color_values = np.array([color_map[label] for label in labels_to_plot])

    # Plot t-SNE
    fig, ax = plt.subplots(figsize=(10, 8))
    scatter = ax.scatter(
        tsne_embeddings[:, 0],
        tsne_embeddings[:, 1],
        c=color_values,
        s=15,
        alpha=1.0
    )
    plt.title('t-SNE Visualization (True Cell Types)', fontsize=15)
    plt.xlabel('T-SNE Component 1', fontsize=12)
    plt.ylabel('T-SNE Component 2', fontsize=12)

    # Add legend (using true cell type names)
    handles = [mpatches.Patch(color=color_map[label], label=label) for label in unique_labels]
    # Adjust legend position to avoid overlap (modify bbox_to_anchor as needed)
    ax.legend(handles=handles, title="Cell Type", loc='center left', bbox_to_anchor=(1, 0.5), fontsize=10)

    # Save image
    tsne_save_path = "E:/jsj/user03/scATAC_data/human_pbmc3k/new_tsne_with_celltypes1.png"
    plt.tight_layout()
    plt.savefig(tsne_save_path, dpi=300, bbox_inches='tight')
    print(f"t-SNE visualization saved to: {tsne_save_path}")

    print("All results successfully saved")
