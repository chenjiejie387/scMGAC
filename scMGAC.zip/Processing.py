from sklearn.preprocessing import MinMaxScaler
import scanpy as sc
import pandas as pd
import numpy as np
from scipy.sparse import csr_matrix
from sklearn.metrics.pairwise import cosine_similarity

def preprocess_gene_expression(adata, num_hvg=2000):
    sc.pp.normalize_total(adata, target_sum=1e4)
    sc.pp.log1p(adata)
    sc.pp.highly_variable_genes(adata, n_top_genes=num_hvg, flavor="seurat")
    return adata[:, adata.var["highly_variable"]]


def process_activity_matrix(activity_matrix, top_n=2000, k_for_knn=20, return_sparse=True):
    cell_gene_matrix = activity_matrix.T
    cell_gene_matrix.columns = cell_gene_matrix.columns.astype(str)  # Force column names to be of string type
    scaler = MinMaxScaler()
    normalized_matrix = pd.DataFrame(
        scaler.fit_transform(cell_gene_matrix),
        columns=cell_gene_matrix.columns
    )

    gene_variances = normalized_matrix.var(axis=0)
    top_genes = gene_variances.nlargest(top_n).index
    filtered_matrix = cell_gene_matrix[top_genes]

    sim_matrix = cosine_similarity(filtered_matrix)
    knn_indices = np.argsort(-sim_matrix, axis=1)[:, 1:k_for_knn + 1]

    n_cells = filtered_matrix.shape[0]
    row_indices = np.repeat(np.arange(n_cells), k_for_knn)
    col_indices = knn_indices.flatten()
    weights = sim_matrix[row_indices, col_indices]

    adj_matrix = csr_matrix((weights, (row_indices, col_indices)), shape=(n_cells, n_cells))
    adj_matrix = adj_matrix.maximum(adj_matrix.transpose())
    adj_matrix.setdiag(0)

    if not return_sparse:
        adj_matrix = adj_matrix.toarray()

    print(f"ATAC adjacency matrix shape: {adj_matrix.shape} (cells × cells)")
    print(f"Filtered feature matrix shape: {filtered_matrix.shape} (cells × genes)")
    return adj_matrix, filtered_matrix
